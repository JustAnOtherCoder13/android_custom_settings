#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import com.hannesdorfmann.adapterdelegates4.ListDelegationAdapter

class ${NAME}ViewAdapter : ListDelegationAdapter<List<Any>>() {

    init {
        /*delegatesManager
            .addDelegate(YourAdapterDelegate())
        */
    }

    fun setViewModels(viewModels: List<Any>) {
        setItems(viewModels)
        notifyDataSetChanged()
    }
}