#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class ${NAME}Adapter : RecyclerView.Adapter<${NAME}Adapter.ViewHolder>() {

    private val viewModels = ArrayList<${VIEW_MODEL}>()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val view = ${VIEW_NAME}(parent.context)
        view.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val viewModel = viewModels[position]
        holder.view.setViewModel(viewModel)
    }

    override fun getItemCount(): Int {
        return viewModels.size
    }

    fun setViewModels(viewModels: List<${VIEW_MODEL}>) {
        this.viewModels.clear()
        this.viewModels.addAll(viewModels)
        notifyDataSetChanged()
    }

    class ViewHolder(val view: ${VIEW_NAME}) : RecyclerView.ViewHolder(view)
}
