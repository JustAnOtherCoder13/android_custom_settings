#set($item = "")
#set($foreach = "")
#set($packageToFolder = "")
#set($folderToRes = "../res/")
#foreach ($item in ${StringUtils.split(${PACKAGE_NAME},".")})
#set($packageToFolder = "$!packageToFolder../")
#if ($foreach.hasNext == false)
#set($packageToFolderValue = "$!packageToFolder$folderToRes")
#end
#end
$packageToFolderValue