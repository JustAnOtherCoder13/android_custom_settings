#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}

#end
#parse("File Header.java")
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hannesdorfmann.adapterdelegates4.AbsListItemAdapterDelegate

class ${NAME}ViewAdapterDelegate :
    AbsListItemAdapterDelegate<Any, Any, ${NAME}ViewAdapterDelegate.ViewHolder>() {

    override fun isForViewType(item: Any, items: MutableList<Any>, position: Int): Boolean {
        return item is ${NAME}ViewModel
    }

    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val view = ${NAME}View(parent.context)
        view.layoutParams = RecyclerView.LayoutParams(
            RecyclerView.LayoutParams.MATCH_PARENT,
            RecyclerView.LayoutParams.WRAP_CONTENT
        )
        return ViewHolder(view)
    }

    override fun onBindViewHolder(item: Any, holder: ViewHolder, payloads: MutableList<Any>) {
        holder.view.setViewModel(item as ${NAME}ViewModel)
    }

    class ViewHolder(val view: ${NAME}View) : RecyclerView.ViewHolder(view)
}
