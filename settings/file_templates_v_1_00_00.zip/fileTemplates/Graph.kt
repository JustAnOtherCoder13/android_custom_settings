#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}
import android.annotation.SuppressLint
import android.content.Context

#end
#parse("File Header.java")
class ${NAME} private constructor(private val context: Context) {

    //private val yourManager by lazy { YourModule().createYourManager() }

    companion object {

        @SuppressLint("StaticFieldLeak")
        private lateinit var graph: ${NAME} 

        fun initialize(context: Context) {
            graph = ${NAME}(context)
            // init needed graph to start app here
            // use initialize in your Application.kt 
        }

       // fun getYourManager() = graph.yourManager
}
