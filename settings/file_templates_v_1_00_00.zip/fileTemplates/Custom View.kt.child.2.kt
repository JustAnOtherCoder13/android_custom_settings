#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}_view

#end
#parse("File Header.java")

class #parse("FeatureToCamelCase.kt")Presenter(
 private val screen : #parse("FeatureToCamelCase.kt")ViewContract.Screen
) : #parse("FeatureToCamelCase.kt")ViewContract.UserAction {

    override fun onAttachedToWindow(){
    
    }
    
     override fun onDetachedFromWindow(){
     
     }
}