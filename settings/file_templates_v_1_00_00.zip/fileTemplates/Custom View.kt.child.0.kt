#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME}.${NAME}_view

#end
#parse("File Header.java")

interface #parse("FeatureToCamelCase.kt")ViewContract {

    interface UserAction {

        fun onAttachedToWindow()

        fun onDetachedFromWindow()
    }

    interface Screen {
    
    }
}